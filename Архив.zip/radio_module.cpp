#include "config.h"
#include "radio_module.h"
#include <Arduino.h>
#include <AudioGeneratorMP3.h>
#include <AudioFileSourceHTTPStream.h>

#include "AudioFileSourceBuffer.h"
#include <AudioFileSourceICYStream.h>
//#include <AudioOutputI2S.h>
//#include "AudioOutputPDM.h"

#include "AudioOutputI2SNoDAC.h"


//#include <AudioGeneratorMP3.h>
//#include <ogg.h> 
//#include <AudioGeneratorOgg.h>
//#include <AudioFileSourceICYStream.h>

// includes for SD card
#include <SD.h>
#include <AudioFileSourceSD.h>
#include <vector>
#include <algorithm>

// Объекты аудио
AudioGeneratorMP3 *mp3 = nullptr;

//extern SPIClass SDSPI();   // глобальный объект VSPI
extern bool sdCardInitialized;
  
// === ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ===
char currentTitle[256] = "";
char currentArtist[256] = "";
char currentSongInfo[512] = "";

// === ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ===
volatile bool radioTaskShouldStop = false;   // Команда стоп
volatile bool radioTaskStopped = true;      // Подтверждение остановки
volatile bool radioIsPlayingFlag = false;    // Состояние вместо isPlaying
int pendingStationIndex = -1;

// === ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ===
volatile bool radioTaskShouldClear = false;
volatile bool radioTaskIsIdle = true;
unsigned long lastDebugTime = 0;  // Для редкого вывода состояния

TaskHandle_t radioTaskHandle = NULL;  // Важно: инициализируем NULL


// Замени AudioFileSourceHTTPStream на AudioFileSourceICYStream
//AudioFileSourceICYStream *fileSource= nullptr;
//AudioFileSourceHTTPStream *fileSource = nullptr;  // рабочий для wifi radio
AudioFileSource *fileSource = nullptr;   // для SD вместо AudioFileSourceHTTPStream *file

//dac mode
//AudioOutputI2S *out = nullptr;  // dac
//AudioGeneratorMOD *mod;
//pdm pin 26
//AudioOutputPDM *out;// = nullptr;  

AudioOutputI2SNoDAC *out = nullptr;
AudioFileSourceBuffer *buff = nullptr;

// Переменные состояния
int currentStationIndex = 0;
uint8_t currentVolume = 50;

// === Добавь глобальные переменные (после currentVolume) ===
extern int radioPlaySource;        // 0=SD, 1=WiFi, 2=Ext
extern String radioSDFolder;
std::vector<String> sdPlaylist;
int currentSDTrack = 0;
bool sdPlaylistLoaded = false;

bool isPlaying = false;
unsigned long lastSwitchTime = 0;
#define MIN_SWITCH_INTERVAL 500

// Перечисление форматов
enum AudioFormat { FORMAT_MP3, FORMAT_OGG, FORMAT_UNKNOWN };


// FreeRTOS таск
SemaphoreHandle_t radioMutex = NULL;
//TaskHandle_t radioTaskHandle = NULL;

// === ИНИЦИАЛИЗАЦИЯ ===
void radioInit() {
    //out = new AudioOutputI2S(0, 2, 8, -1);
    //radioMutex  = xSemaphoreCreateMutex();
    //out = new AudioOutputPDM(26);
    out = new AudioOutputI2SNoDAC(26);
    //out->SetPinout(26);
    //out->SetOutputModeMono(true);
    out->SetGain(currentVolume / 100.0);
    //Serial.println("Radio initialized (GPIO25/26 DAC, mono)");
    //out->
    Serial.println("Radio initialized (GPIO26)");
}

// Called when a metadata event occurs (i.e. an ID3 tag, an ICY block, etc.
void MDCallback(void *cbData, const char *type, bool isUnicode, const char *string) {
  const char *ptr = reinterpret_cast<const char *>(cbData);
  (void) isUnicode; // Punt this ball for now
  // Note that the type and string may be in PROGMEM, so copy them to RAM for printf
  char s1[32], s2[64];
  strncpy_P(s1, type, sizeof(s1));
  s1[sizeof(s1) - 1] = 0;
  strncpy_P(s2, string, sizeof(s2));
  s2[sizeof(s2) - 1] = 0;
  Serial.printf("METADATA(%s) '%s' = '%s'\n", ptr, s1, s2);
  Serial.flush();
}

void StatusCallback(void *cbData, int code, const char *string) {
  const char *ptr = reinterpret_cast<const char *>(cbData);
  // Note that the string may be in PROGMEM, so copy it to RAM for printf
  char s1[64];
  strncpy_P(s1, string, sizeof(s1));
  s1[sizeof(s1) - 1] = 0;
  Serial.printf("STATUS(%s) '%d' = '%s'\n", ptr, code, s1);
  Serial.flush();
}

// === УПРОЩЁННАЯ ПАУЗА (только mute) ===
void radioPause() {
    Serial.println("\n[PAUSE] Mute only");
    //if (out) out->SetGain(0.0);
    radioStop();
    // Не ждём остановки таска, просто глушим звук
    // Объекты останутся, таск продолжит работать в фоне
}

/*
// === ПАУЗА (без force delete) ===
void radioPause() {
    Serial.println("\n[PAUSE] ===== START =====");
    
    // Сразу глушим звук (чтобы не ждать)
    if (out) {
        out->SetGain(0.0);
        Serial.println("[PAUSE] Gain set to 0");
    }
    
    if (radioTaskHandle == NULL) {
        // Таск не запущен, просто чистим объекты
        if (mp3) { delete mp3; mp3 = nullptr; }
        if (fileSource ) { delete fileSource ; fileSource  = nullptr; }
        radioTaskIsIdle = true;
        radioTaskShouldClear = false;
        Serial.println("[PAUSE] No task, cleaned objects");
    } else {
        // Отправляем команду остановки
        radioTaskShouldClear = true;
        Serial.println("[PAUSE] Waiting for task to stop...");
        
        // Ждем до 3 секунд (300 * 10ms)
        int timeout = 300;
        while (!radioTaskIsIdle && timeout-- > 0) {
            vTaskDelay(pdMS_TO_TICKS(10));
        }
        
        if (!radioTaskIsIdle) {
            Serial.println("[PAUSE] WARNING: Task is stuck in network I/O!");
            Serial.println("[PAUSE] Objects will remain until task frees them");
            // НЕ удаляем таск, просто выходим
            // UI должен показать ошибку и не дать нажать Next/Play
        } else {
            Serial.println("[PAUSE] Task stopped gracefully");
        }
    }
    
    radioTaskShouldClear = false;
    Serial.printf("[PAUSE] End: isIdle=%d\n", radioTaskIsIdle);
    Serial.println("[PAUSE] ===== END =====\n");
}
*/
// === PLAY/RESUME ===
void radioResume() {
    Serial.println("[RESUME]");
    if (out) out->SetGain(currentVolume / 100.0);
}

// === PLAY STATION (с проверкой на тот же индекс) ===
void radioPlayStation(int index) {
    Serial.printf("\n[PLAY] index=%d, current=%d, isIdle=%d\n", 
        index, currentStationIndex, radioTaskIsIdle);
    
    if (index < 0 || index >= RADIO_STATION_COUNT) return;
    
    // Если это тот же индекс что сейчас играет - просто включаем звук (resume)
    if (index == currentStationIndex && !radioTaskIsIdle) {
        Serial.println("[PLAY] Same station, resuming...");
        radioResume();
        return;
    }

    if (!out) 
    {
       // out->SetGain(0.0);
        out->begin();
        out->SetGain(currentVolume / 100.0);
        //out->flush();
    }
    // Если другая станция - нужно остановить текущую
    if (!radioTaskIsIdle) {
        Serial.println("[PLAY] Stopping current station...");
        radioTaskShouldClear = true;
        
        // Ждём остановки (макс 5 сек)
        int timeout = 500;
        while (!radioTaskIsIdle && timeout-- > 0) {
            vTaskDelay(pdMS_TO_TICKS(10));
        }
        
        if (!radioTaskIsIdle) {
            Serial.println("[PLAY] ERROR: Cannot stop, network busy");
            // Покажи на экране "Wait for network..."
            return;
        }
    }
    
    // Очищаем старые объекты если остались
    if (mp3) { delete mp3; mp3 = nullptr; }
    if (fileSource) { delete fileSource ; fileSource = nullptr; }
    radioTaskShouldClear = false;
    
    // Создаём новое подключение...
    char url[128];
    strncpy_P(url, (char*)pgm_read_ptr(&radioStations[index].url), sizeof(url)-1);
    url[sizeof(url)-1] = '\0';
    
    Serial.printf("[PLAY] Connecting: %s\n", url);
    //fileSource = new AudioFileSourceHTTPStream(url);
    fileSource = new AudioFileSourceHTTPStream(url);
    unsigned long start = millis();
    while (fileSource && fileSource->getSize() < 1024) {
        if (millis() - start > 5000) {
            Serial.println("[PLAY] Timeout");
            delete fileSource; fileSource = nullptr;
            return;
        }
        vTaskDelay(pdMS_TO_TICKS(10));
    }
    
    mp3 = new AudioGeneratorMP3();
    mp3->RegisterStatusCB(StatusCallback, (void*)"mp3");
    
    if (mp3->begin(fileSource, out)) {
        radioTaskIsIdle = false;
        if (out) out->SetGain(currentVolume / 100.0);
        currentStationIndex = index;
        Serial.println("[PLAY] Started");
    } else {
        delete mp3; mp3 = nullptr;
        delete fileSource; fileSource = nullptr;
    }
}

// === ПОЛНОЕ ВЫКЛЮЧЕНИЕ РАДИО ===
void radioStop() {
    Serial.println("\n[STOP] ===== FULL SHUTDOWN =====");
    
    // 1. Сразу глушим звук (чтобы не было щелчков)

    
    // 2. Если таск не запущен - просто чистим
    if (radioTaskHandle == NULL) {
        cleanupRadioObjects();
        Serial.println("[STOP] Task not running, cleaned");
        return;
    }
    
    // 3. Отправляем команду остановки
    radioTaskShouldClear = true;
     radioIsPlayingFlag = false;
    
    // 4. Ждём с таймаутом 5 секунд
    Serial.println("[STOP] Waiting for task to stop...");
    int timeout = 500;
    while (!radioTaskIsIdle && timeout-- > 0) {
        vTaskDelay(pdMS_TO_TICKS(10));
    }
        if (out) 
    {
        out->SetGain(0.0);
        //out->stop();
        out->flush();
    }
    // 5. Если таск завис в сети - принудительно "обрубаем" соединение
    // Удаление fileSource прервёт блокирующий read() в таске!
    if (!radioTaskIsIdle && fileSource != nullptr) {
        Serial.println("[STOP] Forcing network disconnect...");
        
        // ВАЖНО: Удаляем fileSource ПОСЛЕ небольшой задержки, 
        // чтобы таск вышел из текущей итерации loop()
        vTaskDelay(pdMS_TO_TICKS(1500));
        
        // Теперь безопасно удалить (таск в следующей итерации увидит nullptr)
        if (fileSource) {
            delete fileSource;
            fileSource = nullptr;
        }
        // Ждём, пока таск обработает ошибку чтения
        vTaskDelay(pdMS_TO_TICKS(300));
    }
    
    // 6. Окончательная очистка
    cleanupRadioObjects();
    
    // 7. Сбрасываем состояние
    //currentStationIndex = -1;  // Сбрасываем станцию
    //radioIsPlayingFlag = false;
    
    Serial.println("[STOP] Radio fully stopped");
    Serial.println("[STOP] ===== END =====\n");
}

// Вспомогательная функция очистки (вызывать только когда таск остановлен!)
void cleanupRadioObjects() {
    if (mp3) {
        mp3->stop();
        delete mp3;
        mp3 = nullptr;
    }
    if (buff) {
        delete buff;
        buff = nullptr;
    }

    if (fileSource) { delete fileSource; fileSource = nullptr; }
    radioTaskShouldClear = false;
    radioTaskIsIdle = true;
}

// === ТАСК (без изменений, но с проверкой handle) ===
void radioTask(void *parameter) {
    Serial.println("[TASK] Started");
    
    while (true) {
        // Проверка команды очистки
        if (radioTaskShouldClear) {
            if (mp3) {
                mp3->stop();
                vTaskDelay(pdMS_TO_TICKS(50));
                delete mp3;
                mp3 = nullptr;
            }
            if (fileSource ) {
                delete fileSource ;
                fileSource  = nullptr;
            }
            radioTaskIsIdle = true;
            radioTaskShouldClear = false;
            Serial.println("[TASK] Cleared, going idle");
            //radioStop();
            continue;
        }
        
        // Если нет объектов — ждем
        if (!mp3) {
            radioTaskIsIdle = true;
            vTaskDelay(pdMS_TO_TICKS(50));
            continue;
        }
        
        // Воспроизведение
        radioTaskIsIdle = false;

        if (mp3 && mp3->isRunning()) {
          if (!mp3->loop()) {
            if (radioPlaySource == 0 && !sdPlaylist.empty()) {
              // авто-переход на следующий трек
              currentSDTrack = (currentSDTrack + 1) % sdPlaylist.size();
              if (fileSource) { 
                if (fileSource) { delete fileSource; fileSource = nullptr; }
               }
              fileSource = new AudioFileSourceSD(sdPlaylist[currentSDTrack].c_str());

              String fname = sdPlaylist[currentSDTrack];
              int ls = fname.lastIndexOf('/');
              if (ls >= 0) fname = fname.substring(ls + 1);
              strncpy(currentTitle, fname.c_str(), sizeof(currentTitle) - 1);
              currentArtist[0] = '\0';

              if (mp3->begin(fileSource, out)) {
                Serial.println("[TASK] Auto next SD track");
                continue;
              }
            }
            radioTaskShouldClear = true;
          }
        }

        /*
        if (mp3->isRunning()) {
            if (!mp3->loop()) {
                // Поток оборвался
                radioTaskShouldClear = true;
            }
        } //else {
          //  radioTaskShouldClear = true;
        //}
        */
        
        vTaskDelay(pdMS_TO_TICKS(2));
    }
}

/*
// === ТАСК (упрощённый, без мьютекса) ===
void radioTask(void *parameter) {
    while (true) {
        // Проверяем команду остановки
        if (radioTaskShouldStop) {
            if (mp3) {
                mp3->stop();  // Безопасно, mp3->stop() можно вызывать многократно
                vTaskDelay(pdMS_TO_TICKS(50));
                delete mp3;
                mp3 = nullptr;
            }
            if (fileSource )
            {
                delete fileSource ;
                fileSource  = nullptr;
            }
            radioTaskStopped = true;
            radioTaskShouldStop = false;
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }
       
        if (radioTaskStopped)
        {
            vTaskDelay(pdMS_TO_TICKS(50));
            continue;
        }

        if (mp3 && mp3->isRunning()) {
            if (!mp3->loop()) {
                radioTaskShouldStop = true;
            }
         } else
            {
                radioTaskShouldStop = true;
            }
                
            
        
        vTaskDelay(pdMS_TO_TICKS(2));
    }
}

/*
// === ТАСК ДЛЯ ОТДЕЛЬНОГО ЯДРА ===
void radioTask(void *parameter) {
    while (true) {
        if (radioTskShouldPause) {
            radioTskIsPaused = true;
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }
        radioTskIsPaused = false;
        //if (xSemaphoreTake(radioMutex, portMAX_DELAY) == pdTRUE)
        if (xSemaphoreTake(radioMutex, pdMS_TO_TICKS(50)) == pdTRUE)
        {
            if (mp3 && mp3->isRunning()) {
                if (!mp3->loop()) {
                    // Поток закончился или ошибка — автопереподключение
                    static unsigned long reconnectTime = 0;
                    if (millis() - reconnectTime > 5000) {
                        reconnectTime = millis();
                        int savedIndex = currentStationIndex;
                        Serial.print("REconnect Radio..");
                        // Остановить и перезапустить текущую станцию
                        if (mp3) mp3->stop();
                        delay(100);
                        xSemaphoreGive(radioMutex);
                        radioPlayStation(savedIndex);
                        continue;
                    }
                }
            }
            xSemaphoreGive(radioMutex);
        }
        
        vTaskDelay(pdMS_TO_TICKS(5)); // 1ms — даём время другим задачам
    }
}
*/

// === ЗАПУСК ТАСКА ===
void radioStartTask() {
    if (radioTaskHandle != NULL) {
        Serial.println("Radio task already running");
        return;
    }
    
    xTaskCreatePinnedToCore(
        radioTask,      // функция таска
        "RadioTask",    // имя
        8192,           // стек 8192 =(8KB — достаточно для аудио)
        NULL,           // параметр
        1,              // приоритет (2 выше, чем loop)
        &radioTaskHandle, // хэндл для управления
        1               // ядро 1 (WiFi обычно на ядре 0)
    );
    
    Serial.println("Radio task started on core 1");
}

// === ОСТАНОВКА ТАСКА (опционально) ===
void radioStopTask() {
    if (radioTaskHandle != NULL) {
        vTaskSuspend(radioTaskHandle);
        //vTaskDelete(radioTaskHandle);
        //radioTaskHandle = NULL;
        Serial.println("Radio task stopped");
    }
}

// === ОСТАЛЬНЫЕ ФУНКЦИИ (без изменений) ===


AudioFormat detectFormat(const char *url) {
    const char *ext = strrchr(url, '.');
    if (!ext) return FORMAT_MP3; // default
    
    if (strcasecmp(ext, ".ogg") == 0 || strcasecmp(ext, ".oga") == 0) return FORMAT_OGG;
    if (strcasecmp(ext, ".mp3") == 0) return FORMAT_MP3;
    
    return FORMAT_MP3; // default
}


// === CALLBACK ДЛЯ ICY ПОТОКА ===
// Вызывается автоматически при получении метаданных от сервера
void ICYMetadataCallback(void *cbData, const char *type, bool isUnicode, const char *string) {
    Serial.printf("[METADATA] Type: %s, Value: %s\n", type, string);
    
    // StreamTitle — основной тег с названием трека
    if (strcmp(type, "StreamTitle") == 0) {
        radioParseMetadata(string);
    }
    // Дополнительные теги (если сервер отправляет)
    else if (strcmp(type, "icy-name") == 0) {
        // Название станции (можно кэшировать)
    }
    else if (strcmp(type, "icy-description") == 0) {
        // Описание станции
    }
}


// === ГЕТТЕРЫ ===
const char* radioGetCurrentTitle() {
    return currentTitle[0] ? currentTitle : "Unknown Title";
}

const char* radioGetCurrentArtist() {
    return currentArtist[0] ? currentArtist : "Unknown Artist";
}

const char* radioGetCurrentSong() {
    return currentSongInfo[0] ? currentSongInfo : "Unknown - Unknown";
}



void radioParseMetadata(const char* rawMetadata) {
    if (!rawMetadata || strlen(rawMetadata) == 0) return;
    
    char buffer[512];
    strncpy(buffer, rawMetadata, sizeof(buffer) - 1);
    buffer[sizeof(buffer) - 1] = '\0';
    
    currentTitle[0] = '\0';
    currentArtist[0] = '\0';
    currentSongInfo[0] = '\0';
    
    // Вариант 1: "Artist - Title"
    char* sep = strstr(buffer, " - ");
    if (sep) {
        *sep = '\0';
        strncpy(currentArtist, buffer, sizeof(currentArtist) - 1);
        strncpy(currentTitle, sep + 3, sizeof(currentTitle) - 1);
    }
    // Вариант 2: "Artist – Title" (длинное тире)
    else if ((sep = strstr(buffer, " – ")) != NULL) {
        *sep = '\0';
        strncpy(currentArtist, buffer, sizeof(currentArtist) - 1);
        strncpy(currentTitle, sep + 3, sizeof(currentTitle) - 1);
    }
    // Вариант 3: "Artist: Title"
    else if ((sep = strchr(buffer, ':')) != NULL) {
        *sep = '\0';
        strncpy(currentArtist, buffer, sizeof(currentArtist) - 1);
        strncpy(currentTitle, sep + 2, sizeof(currentTitle) - 1);
    }
    // Вариант 4: "Title" (только название)
    else {
        strncpy(currentTitle, buffer, sizeof(currentTitle) - 1);
        strncpy(currentArtist, "Unknown Artist", sizeof(currentArtist) - 1);
    }
    
    // Убираем лишние пробелы в начале/конце
    // (опционально, можно добавить trim)
    
    snprintf(currentSongInfo, sizeof(currentSongInfo), "%s - %s", 
             currentArtist, currentTitle);
}


// === Добавь эти функции в конец файла (перед radioLoop) ===

 bool loadSDPlaylist() {
  if (!sdCardInitialized) return false;

  //digitalWrite(5, LOW);   // активируем SD
  
  File root = SD.open(radioSDFolder.c_str());
  if (!root) {
    //digitalWrite(5, HIGH);
    Serial.println("[SD] Cannot open folder");
    return false;
  }

  sdPlaylist.clear();
  File file = root.openNextFile();
  while (file) {
    if (!file.isDirectory()) {
      String name = file.name();
      if (name.endsWith(".mp3") || name.endsWith(".MP3")) {
        String fullPath = radioSDFolder;
        if (!fullPath.endsWith("/")) fullPath += "/";
        fullPath += name;
        sdPlaylist.push_back(fullPath);
      }
    }
    file = root.openNextFile();
  }
  root.close();
  //digitalWrite(5, HIGH);

  std::sort(sdPlaylist.begin(), sdPlaylist.end());
  sdPlaylistLoaded = !sdPlaylist.empty();
  
  Serial.printf("[SD] Loaded %d tracks from %s\n", sdPlaylist.size(), radioSDFolder.c_str());
  return sdPlaylistLoaded;
}


void playSDTrack(int index) {
  if (!sdPlaylistLoaded || index < 0 || index >= (int)sdPlaylist.size()) return;
  currentSDTrack = index;
  
    if (!out) 
    {
       // out->SetGain(0.0);
        out->begin();
        out->SetGain(currentVolume / 100.0);
        //out->flush();
    }
    
    Serial.print("[Radio] Start play");
  radioStop();

  fileSource  = new AudioFileSourceSD(sdPlaylist[index].c_str());
  mp3 = new AudioGeneratorMP3();
  mp3->RegisterStatusCB(StatusCallback, (void*)"mp3");

  String fname = sdPlaylist[index];
  int ls = fname.lastIndexOf('/');
  if (ls >= 0) fname = fname.substring(ls + 1);
  strncpy(currentTitle, fname.c_str(), sizeof(currentTitle) - 1);
  currentArtist[0] = '\0';
    Serial.printf("[Radio] Begin mp3: %S\n", sdPlaylist[index].c_str());
  if (mp3->begin(fileSource , out)) {
    radioIsPlayingFlag = true;
    currentStationIndex = -1;
    Serial.println("[SD] Track started");
  } else {
    if (fileSource ) { delete fileSource ; fileSource  = nullptr; }
    delete mp3; mp3 = nullptr;
  }
}

void radioNextSDTrack() {
  if (!sdPlaylistLoaded || sdPlaylist.empty()) return;
  currentSDTrack = (currentSDTrack + 1) % sdPlaylist.size();
  playSDTrack(currentSDTrack);
}


// =============


void radioLoop() {
    // Не используется при таске, но оставлен для совместимости
    if (mp3 && mp3->isRunning()) {
        mp3->loop();
        delay(5);
    }
}
/*
// === PLAY STATION (переписан безопасно) ===
void radioPlayStation(int index) {
    if (index < 0 || index >= RADIO_STATION_COUNT) return;
    
    // Останавливаем текущее
    radioPause(); // Используем нашу безопасную паузу
    
    if (!radioTaskStopped)
    {
    Serial.println("[ERROR] Cannot start. Task busy.");
    return;
    }

    char url[128];
    strncpy_P(url, (char*)pgm_read_ptr(&radioStations[index].url), sizeof(url)-1);
    url[sizeof(url)-1] = '\0';
     AudioFormat fmt = detectFormat(url);
     if (fmt != FORMAT_OGG) 
    {
    Serial.printf("Connecting: %s\n", url);
    
    // Создаём объекты
    //fileSource  = new AudioFileSourceHTTPStream(url);
    // Создаём ICY поток с поддержкой метаданных
    fileSource = new AudioFileSourceICYStream(url);
    
    // Регистрируем callback для метаданных
    
    // Ждём данные с таймаутом
    unsigned long start = millis();
    while (fileSource ->getSize() < 1024) {
        if (millis() - start > 3000) {
            Serial.println("Stream timeout");
            delete fileSource ;
            fileSource = nullptr;
            return;
        }
        delay(10);
    }

    file->RegisterMetadataCB(ICYMetadataCallback, nullptr);
    
    mp3 = new AudioGeneratorMP3();
    
    if (mp3->begin(file, out)) {
        radioIsPlayingFlag = true;
        radioTaskShouldStop = false; // Разрешаем таску работать
        if (out) out->SetGain(currentVolume / 100.0);
        Serial.println("Started");
    } else {
        Serial.println("Failed to start");
        delete mp3;
        mp3 = nullptr;
        delete fileSource ;
        fileSource = nullptr;
    }
    }
}
/*
void radioPlayStation(int index) {
    if (index < 0 || index >= RADIO_STATION_COUNT) return;
    radioTskShouldPause = true;

    vTaskDelay(pdMS_TO_TICKS(100));

    if (radioIsPlaying()) radioPause();

    //if (radioTaskHandle != NULL) 
    //    vTaskResume(radioTaskHandle);

    //if (radioMutex) xSemaphoreTake(radioMutex, portMAX_DELAY);
    if (xSemaphoreTake(radioMutex, pdMS_TO_TICKS(500)) != true)
    {
        Serial.println("[ERROR] Cannot acquire mutex for play");
        return;
    }

    // Очистка старых объектов
    if (mp3) {
        mp3->stop();
        delay(10);
        delete mp3;
        mp3 = nullptr;
    }
    if(buff){
        delete buff;
        buff = nullptr;
    }
    if (fileSource ) {
        delete fileSource ;
        fileSource = nullptr;
    }
    
    radioTskShouldPause = false;
        
    // Очистка метаданных
    currentTitle[0] = '\0';
    currentArtist[0] = '\0';
    currentSongInfo[0] = '\0';
    
    delay(50);
    currentStationIndex = index;
    
    char url[128];
    strncpy_P(url, (char*)pgm_read_ptr(&radioStations[index].url), sizeof(url)-1);
    url[sizeof(url)-1] = '\0';
    
    Serial.printf("Connecting to: %s\n", url);
    
    AudioFormat fmt = detectFormat(url);

    
    // Создаём ICY поток с поддержкой метаданных
    fileSource = new AudioFileSourceICYStream(url);
    
    // Регистрируем callback для метаданных
    fileSource->RegisterMetadataCB(ICYMetadataCallback, nullptr);
    
    //fileSource = new AudioFileSourceHTTPStream(url);
    //fileSource->RegisterMetadataCB(MDCallback, (void*)"ICY");
    unsigned long waitStart = millis();
    while (file->getSize() < 1024)
    {
        if (millis() - waitStart > 3000)
        {
            Serial.println("[ERROR] stream timeout");
            delete file;
            xSemaphoreGive(radioMutex);
            return;
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }

    Serial.printf("New file stream. Size: %d\n", file->getSize());

        switch (fmt) {
        case FORMAT_OGG:
            //mp3 = new AudioGeneratorOgg();  // на самом деле Ogg Vorbis
            Serial.println("Format: OGG. Cancel.");
            break;
        case FORMAT_MP3:
            //mp3 = new AudioGeneratorMP3();
            Serial.println("Format: MP3");
            break;
        default:
            //mp3 = new AudioGeneratorMP3();
            Serial.println("Format: MP3");
            break;
        }

    if (fmt != FORMAT_OGG) 
    {
        mp3 = new AudioGeneratorMP3();
        //Serial.print("New AudioGeneratorMP3\n");
    /*
    buff = new AudioFileSourceBuffer(file, 4096);
    Serial.println("[buffer] prefill");
    unsigned long fillStart = millis();
    while (buff->getFillLevel() < 4096)
    {
        if (millis() - fillStart > 2000) break;
        delay(10);
    }
    Serial.printf("[buffer] prefilled: %d/4096\n", buff->getFillLevel());

    buff->RegisterStatusCB(StatusCallback, (void*)"buffer");
    
    ///////// *****
    mp3->RegisterStatusCB(StatusCallback, (void*)"mp3");
    //mp3->begin(buff, out);
        if (mp3->begin(fileSource, out)) {
            isPlaying = true;
            Serial.println("Playback started");
        } else {
            Serial.println("Failed to start playback");
            delete mp3;
            mp3 = nullptr;
            delete fileSource;
            fileSource = nullptr;
        }
    }

    xSemaphoreGive(radioMutex);

}
*/

// === Обнови radioNextStation / radioPrevStation ===
void radioNextStation() {
  if (millis() - lastSwitchTime < MIN_SWITCH_INTERVAL) return;
  lastSwitchTime = millis();

  if (radioPlaySource == 0) {
    radioNextSDTrack();
    return;
  }
  int next = currentStationIndex + 1;
  if (next >= RADIO_STATION_COUNT) next = 0;
  radioPlayStation(next);
}

void radioPrevStation() {
  if (millis() - lastSwitchTime < MIN_SWITCH_INTERVAL) return;
  lastSwitchTime = millis();

  if (radioPlaySource == 0) {
    if (!sdPlaylistLoaded || sdPlaylist.empty()) return;
    currentSDTrack = (currentSDTrack - 1 + sdPlaylist.size()) % sdPlaylist.size();
    playSDTrack(currentSDTrack);
    return;
  }
  int prev = currentStationIndex - 1;
  if (prev < 0) prev = RADIO_STATION_COUNT - 1;
  radioPlayStation(prev);
}


/*
void radioPrevStation() {
    if (millis() - lastSwitchTime < MIN_SWITCH_INTERVAL) return;
    lastSwitchTime = millis();
    radioPause();
    int prev = currentStationIndex - 1;
    if (prev < 0) prev = RADIO_STATION_COUNT - 1;
    radioPlayStation(prev);
}
*/

// === Обнови radioPlay() ===
void radioPlay() {
  if (radioPlaySource == 0) { // SD
    if (!sdPlaylistLoaded) loadSDPlaylist();
    if (sdPlaylist.empty()) {
      Serial.println("[SD] No MP3 files");
      return;
    }

    Serial.println("[Radio] Start playing from SD");
    playSDTrack(currentSDTrack);
  } else if (radioPlaySource == 1) { // WiFi
    if (currentStationIndex < 0) currentStationIndex = 0;
    Serial.println("[Radio] Start playing radio from WiFi");
    radioPlayStation(currentStationIndex);
  } else {
    Serial.println("[Ext] Not implemented");
  }
}

// === БЕЗОПАСНАЯ ПАУЗА (без мьютексов) ===
/*
void radioPause() {
    
   if (radioTaskStopped) return;
   Serial.println("Pause requested...");
    // 1. Команда на остановку
    radioTaskShouldStop = true;
    
    // 2. Ждём подтверждения (максимум 1 секунда)
    int timeout = 100;
    while (!radioTaskStopped && timeout-- > 0) {
        vTaskDelay(pdMS_TO_TICKS(10));
    }
    
    if (!radioTaskStopped)
    {
    Serial.println("[ERROR] Task stop timeout!");
    //return;
    }
    else
    Serial.println("Pause OK");
    // 3. Очищаем I2S буфер (чтобы не "застрял" звук)
    if (out) {
        out->SetGain(0.0);
        // Для AudioOutputI2SNoDAC пробуем "заглушить" выход
        // Иногда нужно явно остановить I2S
        delay(50); // Даем DMA закончить текущий блок
    }
    
    // 4. Теперь безопасно удаляем объекты (таск остановился)
    if (mp3) {
        //mp3->stop();
        delay(50);
        delete mp3;
        mp3 = nullptr;
    }
    if (buff) {
        delete buff;
        buff = nullptr;
    }
    if (fileSource) {
        delete fileSource;
        fileSource= nullptr;
    }
    
    radioIsPlayingFlag = false;
    radioTaskShouldStop = false; // Сбрасываем команду
    isPlaying = false;
    Serial.println("Paused OK");
}

/*
void radioPause() {
    Serial.println("Radio pause requested..");
    radioTskShouldPause = true;
    int retries = 50;
    while(!radioTskIsPaused && retries-- > 0)
    {
        vTaskDelay(pdMS_TO_TICKS(10));
    }

    if (xSemaphoreTake(radioMutex, pdMS_TO_TICKS(300)) != pdTRUE){
        Serial.println("[ERROR] Timeout acquiring mutex in pause");
    };

    isPlaying = false;
    if (out) out->SetGain(0.0);
    delay(100);
    //radioStopTask();
    // Очистка старых объектов
    if (mp3) {
        mp3->stop();
        delay(10);
        delete mp3;
        mp3 = nullptr;
    }
    if(buff){
        delete buff;
        buff = nullptr;
    }
    if (fileSource) {
        delete fileSource;
        fileSource= nullptr;
    }
     xSemaphoreGive(radioMutex);
     Serial.println("radio pause succesfully");
}



void radioSetVolume(uint8_t vol) {
    if (vol > 100) vol = 100;
    currentVolume = vol;
    if (out && isPlaying) {
        out->SetGain(vol / 100.0);
    }
}


bool radioIsPlaying() {
    return isPlaying && mp3 && mp3->isRunning();
}
*/
// === VOLUME ===
void radioSetVolume(uint8_t vol) {
    if (vol > 100) vol = 100;
    currentVolume = vol;
    if (out)// && radioIsPlayingFlag) {
        out->SetGain(vol / 100.0);
   // }
}

bool radioIsPlaying() {
    return radioIsPlayingFlag;
}

uint8_t radioGetVolume() {
    return currentVolume;
}

const char* radioGetStationName() {
    static char name[32];
    strncpy_P(name, (char*)pgm_read_ptr(&radioStations[currentStationIndex].name), sizeof(name)-1);
    name[sizeof(name)-1] = '\0';
    return name;
}

int radioGetStationIndex() {
    return currentStationIndex;
}
