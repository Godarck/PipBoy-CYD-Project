#ifndef RADIO_MODULE_H
#define RADIO_MODULE_H

#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

// === ТАЙМАУТЫ ===
#define STREAM_CONNECT_TIMEOUT 10000    // 10 сек на подключение
#define STREAM_READ_TIMEOUT 5000        // 5 сек на чтение данных
#define MP3_VALIDATION_BYTES 1024       // Сколько байт проверить для валидации MP3


#define ICON_WIDTH 50
#define ICON_HEIGHT 50

struct RadioStation {
    const char* name;
    const char* url;
};


//extern const int RADIO_STATION_COUNT;

// Глобальные переменные метаданных
extern char currentTitle[256];
extern char currentArtist[256];
extern char currentSongInfo[512];  // Полная строка "Artist - Title"

extern SemaphoreHandle_t radioMutex;

const RadioStation radioStations[] PROGMEM = {
    // Игровое и специфическое
    //{"Radio Pip-Boy", "http://fallout.fm:8000/falloutfm1.ogg"},  // Fallout OST! not working with ogg
    // Интернациональные
    {"Groove Salad", "http://ice1.somafm.com/groovesalad-128-mp3"},
    {"Radio Paradise", "http://stream.radioparadise.com/mp3-128"},
    
    // Русские рок и альтернатива
    {"Nashe Radio", "http://nashe1.hostingradio.ru:80/nashe-128.mp3"},
    {"Nashe2.0", "http://nashe2.hostingradio.ru:80/nashe20-128.mp3"},
    {"Radio Zenit", "http://radio.zenit.ru:8000/zenit128"},
    {"Radio Punk", "http://stream.punkradio.ru:8000/punk128"},
    {"Radio Metal", "http://stream.metallradio.ru:8000/metal128"},
    
    // Поп и хиты
    {"Evropa +", "http://ep128.hostingradio.ru:8059/europaplus128.mp3"},
    {"Russkoe Radio", "http://rusradio.hostingradio.ru:80/rusradio-128.mp3"},
    {"HIT  FM", "http://hitfm.hostingradio.ru:80/hitfm-128.mp3"},
    {"Radio Dacha", "http://radiodacha.hostingradio.ru:8002/radiodacha128.mp3"},
    {"Love Radio", "http://loveradio.hostingradio.ru:80/loveradio-128.mp3"},
    
    // Ретро и советское
    {"Avtoradio", "http://avtoradio.hostingradio.ru:80/avtoradio-128.mp3"},
    {"Radio Shanson", "http://chanson.hostingradio.ru:8041/chanson-128.mp3"},
    {"Retro FM", "http://retro.hostingradio.ru:8042/retro-128.mp3"},
    {"Radio Umor FM", "http://humorfm.hostingradio.ru:8000/humorfm128.mp3"},
    
    // Джаз и классика
    {"Radio Jazz", "http://jazzfm.ru:8000/jazz"},
    {"РRadio Orphey", "http://orfeyfm.hostingradio.ru:8000/orfeyfm128.mp3"},
    
    // Разговорное и новости
    {"Eho Moscow", "http://ice912.echo.msk.ru:8000/echo-mp3-128"},
    {"Radio Mayak", "http://icecast.vgtrk.cdnvideo.ru/mayakfm_mp3_128kbps"},
    {"Vesti FM", "http://icecast.vgtrk.cdnvideo.ru/vestifm_mp3_128kbps"},
    
    // Электроника и chillout
    {"DI Chillout", "http://stream.di.fm/chillout"},
    {"Radio Trance", "http://air.radiorecord.ru:805/trance_128"},
    {"Radio Record", "http://air.radiorecord.ru:805/rr_128"},
    
    
};

#define RADIO_STATION_COUNT (sizeof(radioStations) / sizeof(radioStations[0]))

// Основные функции

void radioInit();
void radioLoop();  // Не обязателен при использовании таска
void radioStartTask();  // ← НОВОЕ: запуск в отдельном ядре
void radioStopTask();   // ← НОВОЕ: остановка таска
void radioTask(void *parameter);
void radioStop();
void cleanupRadioObjects();
// Информация о станции
const char* radioGetStationName();


// === МЕТАДАННЫЕ ===
void radioParseMetadata(const char* rawMetadata);  // Парсинг сырой строки
const char* radioGetCurrentTitle();                // Название трека
const char* radioGetCurrentArtist();               // Исполнитель
const char* radioGetCurrentSong();                 // Полная строка "Artist - Title"

void radioPlayStation(int index);
void radioNextStation();
void radioPrevStation();
void radioPlay();
void radioPause();
void radioSetVolume(uint8_t vol);
uint8_t radioGetVolume();
bool radioIsPlaying();
int radioGetStationIndex();

#endif
